import React from "react";
import TodoList from './../todoList';
import Input from './../elements/input';
import Button from './../elements/button';
import './index.css';

class TodoListBlock extends React.Component{

    constructor() {
        super();
        this.state = {
            todo: {id:'',name:''},
            todoList :[],
        }
    }
    setTodo(value){
        this.setState({todo: {id:this.state.todoList.length+1,name:value}});
    };
    updateTodoList =()=>{
        let newArray = this.state.todoList;
        newArray.push(this.state.todo);
        this.setState({todoList : newArray});
        this.setState({todo: {id:'',name:''}});
    };

    render() {
        return (
            <div className='block'>
                <div className='header'>
                    <Input type='text' value={this.state.todo.name} onChange={(e)=>{this.setTodo(e.target.value)}}> Name of row</Input>
                    <Button onClick={this.updateTodoList} className='add-button'> Add row</Button>
                </div>
                <TodoList todoList ={this.state.todoList}/>

            </div>
        )
    }

}

export default TodoListBlock;