import React from 'react';
import SelectAnt from './../elements/select'

const Row = (props) => {
    let item = props.item;
    return (
        <div className='list'>
            <span className='name' id={item.id}>
                {item.name}
            </span>
            <SelectAnt fields={[
                {
                    value: 'check',
                    label: 'check',
                },
                {
                    value: 'hide',
                    label: 'hide',
                },
                {
                    value: 'delete',
                    label: 'delete',
                },
                {
                    value: 'edith',
                    label: 'edith',
                },
            ]}/>
        </div>

    );
};

export default Row;